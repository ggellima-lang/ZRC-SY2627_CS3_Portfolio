    Using @property makes my code easier to read because I can get and change values the
same way I use ordinary variables, like rectangle.width and rectangle.width = 5,
instead of calling get_width() and set_width(5). The code is shorter and cleaner,
and the class still validates the data and protects the private attributes behind the
scenes. With traditional get_ and set_ methods, I have to write extra method calls
everywhere, which makes the code longer and more cluttered.