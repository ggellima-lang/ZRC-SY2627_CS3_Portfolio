# ACTIVITY 1: public, protected, or private?

# 1. GameCharacter - username - Public
class GameCharacter:
    def __init__(self, username):
        self.username = username

# 2. BankAccount - balance - Private
class BankAccount:
    def __init__(self, balance):
        self.__balance = balance

# 3. Vehicle - engineCode - Protected
class Vehicle:
    def __init__(self, engineCode):
        self._engineCode = engineCode

# 4. Student - schoolName - Public
class Student:
    def __init__(self, schoolName):
        self.schoolName = schoolName

# 5. VotingSystem - voterID - Private
class VotingSystem:
    def __init__(self, voterID):
        self.__voterID = voterID