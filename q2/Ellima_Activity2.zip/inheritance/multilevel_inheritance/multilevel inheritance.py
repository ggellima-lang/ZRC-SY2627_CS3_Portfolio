class Parent:
    def __init__(self, name):
        self.name = name

    def set_name(self, name):
        self.name = name

    def get_name(self):
        return self.name

    def func1(self):
        print("Parent class:", self.name)

class Child1(Parent):
    def func2(self):
        print("Child 1:", self.name)

class Child2(Parent):
    def func3(self):
        print("Child 2:", self.name)


object1 = Child1("Prince")

object1.func1()

object1.set_name("Gabriel")

object1.func1()