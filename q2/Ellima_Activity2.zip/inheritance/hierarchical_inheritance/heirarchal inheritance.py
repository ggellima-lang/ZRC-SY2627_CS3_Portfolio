class Parent:
    def __init__(self, name):
        self.name = name

    def func1(self):
        print("Parent:", self.name)

class Child1(Parent):
    def func2(self):
        print("Child 1:", self.name)

class Child2(Parent):
    def func3(self):
        print("Child 2:", self.name)


object1 = Child1("Prince")
object2 = Child2("Gabriel")
object3 = Child1("Alex")

object1.func1()
object1.func2()

object2.func1()
object2.func3()

object3.func1()
object3.func2()